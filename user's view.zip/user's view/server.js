const express = require('express');
const {Pool} = require('pg');
const cors = require('cors');
const path = require('path'); // Import the 'path' module
const app = express();
const port = 5500;

const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "test",
    password: "23092004",
    port: 5432,
});

pool.connect()
  .then(() => {
    console.log('Connected to the database');
  })
  .catch(err => {
    console.error('Error connecting to the database:', err);
  });

  pool.query('LISTEN book_due');

  // Xử lý khi nhận được thông báo từ PostgreSQL
  pool.on('notification', (msg) => {
      console.log('Received book due notification:', msg.payload);
      // Thực hiện xử lý thông báo tại đây
  });

  app.use(cors());

  app.use(express.static(path.join(__dirname, 'public')));


  app.get('/viewbook', (req, res) => {
    res.sendFile('D:\Kì 2023.2\CSDL LAB\new ver\tổng hợp\final\main branch\web\Mainpagee.html');
    console.log(`done`);
  });  

app.get('/api/borrowing-info', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM re');
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

app.get('/api/account-info', async (req, res) => {
    pool.query('SELECT * FROM users', (err, dbRes) => {
        if (!err) {
          res.json(dbRes.rows);
      
        } else {
          res.status(500).send(err.message);
        }
      });
    });

    app.get('/api/book-details', (req, res) => {
        const bookTitle = req.query.title;
        pool.query('SELECT * FROM books JOIN authors on books.author_id = authors.author_id WHERE title = $1', [bookTitle], (err, dbRes) => {
            if (err) {
                console.error('Error executing query:', err.stack);
                res.status(500).send(err.message);
            } else {
                if (dbRes.rows.length > 0) {
                    res.json(dbRes.rows[0]); // Trả về thông tin của cuốn sách đầu tiên trong kết quả truy vấn
                } else {
                    res.status(404).send('Book not found');
                }
            }
        });
    });
    

  app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
  });
  